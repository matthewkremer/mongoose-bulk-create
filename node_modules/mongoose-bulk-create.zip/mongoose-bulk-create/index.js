var mongoose = require('mongoose');
var utils = require('mongoose/lib/utils')

function handleSave (promise, self) {
  return utils.tick(function handleSave (err, result) {
    if (err) {
      // If the initial insert fails provide a second chance.
      // (If we did this all the time we would break updates)
      if (self.$__.inserting) {
        self.isNew = true;
        self.emit('isNew', true);
      }
      promise.error(err);
      promise = self = null;
      return;
    }

    self.$__storeShard();

    var numAffected;
    if (result) {
      // when inserting, the array of created docs is returned
      numAffected = result.length
        ? result.length
        : result;
    } else {
      numAffected = 0;
    }

    self.emit('save', self, numAffected);
    promise.complete(self, numAffected);
    promise = self = null;
  });
}

function bulkCreate(docs, fn){
  var promise = new mongoose.Promise
    , args
    , options = {}

  args = docs;

  if ('function' == typeof fn) {
    promise.onResolve(fn);
  }

  var count = args.length;

  if (0 === count) {
    promise.complete();
    return promise;
  }

  var self = this;
  var docs = [];
  var docsInsert = [];
  var docsComplete = [];

  if (this.schema.options.safe) {
    options.safe = this.schema.options.safe;
  }

  args.forEach(function (arg, i) {
    var doc = new self(arg);
    docs[i] = doc;
    var complete = handleSave(function(){}, doc);
    var obj = doc.toObject({ depopulate: 1 });
    doc.$__version(true, obj);
    // this.collection.insert(obj, options, complete);
    doc.$__reset();
    doc.isNew = false;
    doc.emit('isNew', false);
    doc.$__.inserting = true;
    docsInsert[i] = obj;
  });

  this.collection.insert(docsInsert, options, function(err, result){
    if (err){
      promise.error(err);
    }else{
      docsComplete.forEach(function(fn, i){
        fn();
      })
      promise.complete(docs);
    }
  });

}

exports.patchMongoose = function (m){
  m.Model.bulkCreate = bulkCreate;
}